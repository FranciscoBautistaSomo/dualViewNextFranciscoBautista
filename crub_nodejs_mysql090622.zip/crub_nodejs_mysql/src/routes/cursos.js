const express = require('express');
const router = express.Router();


const cursosController = require('../controllers/cursosController');

//router.get('index',cursosController.index);


router.get('/', cursosController.index);
router.post('/loggin', cursosController.loggin);
router.get('/list', cursosController.list);
router.get('/login', cursosController.login);
router.get('/cursosCard', cursosController.cursosCard);
router.post('/add', cursosController.save);
router.get('/delete/:id', cursosController.delete);
router.get('/update/:id', cursosController.edit);
router.post('/update/:id', cursosController.update);

module.exports = router;
