const { request } = require("express");
const session = require('express-session');

const controller = {};

controller.index = (req, res) => {
    res.render('index');
};

controller.login = (req, res) => {
    res.render('login');
};

controller.cursosCard = (req, res) => {
    req.getConnection((err, conn) => {
            conn.query('SELECT * FROM cursos', (err, cursos) => {
                if (err) {
                    res.json(err);
                }               
                res.render('cursosCard', {
                 data: cursos
                });
            });
        });
 };


controller.loggin = (req, res) => {
    
    let user = req.body.userName;
    let passwordUser = req.body.passUser;
    let logOK = false;
    //res.send('Usuario: '+ user + ' Clave ' + passwordUser);
    
    if (user=='admin' && passwordUser =='admin') {
            req.getConnection((err, conn) => {
                conn.query('SELECT * FROM cursos', (err, cursos) => {
                    if (err) {
                        res.json(err);
                    }                                                    
                    res.render('cursos', {
                     data: cursos                     
                    });
                });
            });
    }else { 
        res.send('Nombre de usuario y/o Password incorrecto!');       
        res.end();
    }   
 };

 controller.list = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT * FROM cursos', (err, cursos) => {
            if (err) {
            res.json(err);
            }                            
            res.render('cursos', {
                data: cursos                     
            });
        });
    });   
 };

controller.save = (req, res) =>{
    const data= req.body;
    //var record= { nombre: 'Java', descripcion: 'java para todos pecadorr', horas: 9 };
    console.log(req.body);
    //res.send('works')
    req.getConnection((err, connection) =>{
        //connection.query('INSERT INTO cursos (nombre, descripcion, horas, fechaInicio, fechaFin) SET ?', data, (err, curso)=>{
        connection.query('INSERT INTO cursos SET ?', data, (err, curso)=>{  
           res.redirect('/list');
        });
    });   
};

controller.edit = (req, res) => {
    const { id } = req.params;
    req.getConnection((err, conn) => {
      conn.query("SELECT * FROM cursos WHERE id = ?", [id], (err, rows) => {
        res.render('cursos_edit', {
          data: rows[0]
        })
      });
    });
  };

controller.update = (req, res)=> {
    const { id } = req.params;
    const newCursos = req.body;
    req.getConnection((req, conn)=>{
        conn.query('UPDATE cursos set ? WHERE id= ?', [newCursos, id], (err, rows )=>{
            res.redirect('/list');

        })
    });
}

controller.delete = (req, res) =>{
    /*console.log(req.params.id);
    res.send('works')*/
    //const id = (req.params.id);
    const {id} =req.params;
    req.getConnection((err,conn)=>{
        conn.query('DELETE FROM cursos WHERE id = ?', [id], (err, rows) =>{
            res.redirect('/list');
        });

    });  
};

module.exports = controller;
