-- creating the database
CREATE DATABASE listadoCursos;

-- utilizando la database
USE listadoCursos;

-- crear tabla
CREATE TABLE cursos (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    descripcion VARCHAR(150) NOT NULL,
    horas INT (4) NOT NULL,
    fechaInicio DATETIME NOT NULL,
    fechaFin DATETIME NOT NULL,
    imagen VARCHAR(200) NULL
);

-- para mostrar todas las tablas
SHOW TABLES;

-- para describir la tabla
DESCRIBE cursos;