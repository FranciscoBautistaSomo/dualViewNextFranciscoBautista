const express = require('express');
const path = require('path');
const morgan = require('morgan');
const mysql = require('mysql');
const myConnection = require('express-myconnection');
//const { rootCertificates } = require('tls');

const app=express();

// importing routes
const cursosRoutes = require('./routes/cursos');
//const { urlencoded } = require('express');
app.use(express.static(__dirname+ "./public"));

// settings
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views') );
app.set('view engine', 'ejs');

//Var. de sesión
const session = require('express-session');
app.use(session({
    secret:'secret',
    resave: true,
    saveUninitialized:true
}));


// middlewares
app.use(morgan('dev'));
app.use(myConnection(mysql, {
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database : 'listadocursos'
}, 'single'));
app.use(express.urlencoded({extended: false}));


// routes
app.use('/', cursosRoutes);

//static files
app.use(express.static(path.join(__dirname, 'public')));

app.listen(app.get('port'), () => {
    console.log(`server on port ${app.get('port')}`);
});